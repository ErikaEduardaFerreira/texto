# Extrator de palavras-chave
Página web desenvolvida para extrair palavras-chave de um texto, facilitando a análise e organização de informações.

## Tecnologias utilizadas
- HTML
- CSS
- JavaScript

## Acessando o código
Para acessar o código referente às aulas, clique no seletor `main` do repositório e selecione a aula desejada.

## Notas e créditos
Feito por Giulliana Cestari e Marcelo Paludetto para Start by Alura.
